using System.Collections.Generic;
using System.Windows.Input;
using $ext_projectname$.ViewModels;

namespace $safeprojectname$.ViewModels
{
    public class MainViewModel : IMainViewModel
    {
        public IEnumerable<string> Data => new [] { "design", "time", "data"};
        public ICommand ClickMe => null;
    }
}