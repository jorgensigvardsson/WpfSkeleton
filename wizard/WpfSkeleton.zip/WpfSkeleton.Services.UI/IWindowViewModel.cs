﻿namespace $safeprojectname$
{
    public interface IWindowViewModel
    {
        void OnViewIsLoaded();
        void OnViewIsClosed();
    }
}