﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public interface IService
    {
        IEnumerable<string> GetData();
    }
}
