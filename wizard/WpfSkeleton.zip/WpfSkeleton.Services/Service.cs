﻿using System.Collections.Generic;

namespace $safeprojectname$
{
    public class Service : IService
    {
        public IEnumerable<string> GetData()
        {
            return new[] { "A", "bunch", "of", "sample", "data" };
        }
    }
}