using System.Collections.Generic;
using System.Windows.Input;

namespace $safeprojectname$
{
    public interface IMainViewModel
    {
        IEnumerable<string> Data { get; }
        ICommand ClickMe { get; }
    }
}