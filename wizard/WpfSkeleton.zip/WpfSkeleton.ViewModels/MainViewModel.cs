using System;
using System.Collections.Generic;
using System.Windows.Input;
using GalaSoft.MvvmLight.CommandWpf;
using $ext_projectname$.Services;
using $ext_projectname$.Services.UI;

namespace $safeprojectname$
{
    public class MainViewModel : WindowViewModelBase, IMainViewModel
    {
        private readonly IService m_service;
        private readonly IMessageBoxService m_messageBoxService;

        public MainViewModel(IService service, IMessageBoxService messageBoxService)
        {
            if (service == null)
                throw new ArgumentNullException(nameof(service));

            if (messageBoxService == null)
                throw new ArgumentNullException(nameof(messageBoxService));

            m_service = service;
            m_messageBoxService = messageBoxService;
        }

        public IEnumerable<string> Data => m_service.GetData();

        public ICommand ClickMe => new RelayCommand(() => m_messageBoxService.Show("Hello!", "Test"));
    }
}