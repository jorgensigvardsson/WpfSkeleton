﻿using GalaSoft.MvvmLight;
using $ext_projectname$.Services.UI;

namespace $safeprojectname$
{
    public abstract class WindowViewModelBase : ViewModelBase, IWindowViewModel
    {
        public virtual void OnViewIsLoaded()
        {
            // Override in subclasses when needed
        }

        public virtual void OnViewIsClosed()
        {
            // Override in subclasses when needed
        }
    }
}
